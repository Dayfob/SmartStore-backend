insert into public.product_categories (id, name, slug, description, created_at, updated_at)
values  (1, 'Cameras', 'cameras', 'These are cameras.', '2022-05-01 08:58:59', '2022-05-01 08:58:59'),
        (2, 'Lighting', 'lighting', 'These are lighting devices.', '2022-05-01 08:58:59', '2022-05-01 08:58:59'),
        (3, 'Temperature', 'temperature', 'These are temperature control devices.', '2022-05-01 08:58:59', '2022-05-01 08:58:59');