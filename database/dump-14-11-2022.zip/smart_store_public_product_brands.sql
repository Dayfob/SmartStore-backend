insert into public.product_brands (id, name, slug, description, created_at, updated_at)
values  (1, 'Honeywell', 'honeywell', 'This is Honeywell.', '2022-05-01 08:58:59', '2022-05-01 08:58:59'),
        (2, 'Google', 'google', 'This is Google.', '2022-05-01 08:58:59', '2022-05-01 08:58:59'),
        (3, 'Johnson Controls', 'johnson_controls', 'This is Johnson Controls.', '2022-05-01 08:58:59', '2022-05-01 08:58:59');