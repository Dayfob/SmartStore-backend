insert into public.user_wishlist (id, status, user_id, created_at, updated_at)
values  (1, '-', 1, '2022-05-01 08:58:59', '2022-05-01 08:58:59');