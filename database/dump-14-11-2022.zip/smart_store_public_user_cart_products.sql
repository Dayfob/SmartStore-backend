insert into public.user_cart_products (id, cart_id, item_id, item_amount, created_at, updated_at)
values  (5, 1, 3, 1, '2022-05-09 07:24:08', '2022-05-09 07:24:08'),
        (9, 1, 2, 4, '2022-05-11 08:08:00', '2022-05-11 08:08:08');