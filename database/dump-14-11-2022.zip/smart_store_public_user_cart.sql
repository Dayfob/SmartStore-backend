insert into public.user_cart (id, status, user_id, total_price, created_at, updated_at)
values  (1, '-', 1, 264900, '2022-05-01 08:58:59', '2022-05-11 08:08:08');